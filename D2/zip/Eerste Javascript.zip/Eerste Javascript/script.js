console.log('Hello Winc Academy');

let name = "Lars Roovers";

let x = 15;
let y = 6;

let foo = "foo";
let bar = "bar";

console.log(x + y);
console.log(foo + bar);

console.log(x + y);
console.log(x * y);
console.log(x - y);
console.log(x / y);
console.log(x % y);

let age = 24;
let ageString = "24";
console.log(typeof age);
console.log(typeof ageString);
