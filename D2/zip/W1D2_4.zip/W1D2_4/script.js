const age = 15;
const isFemale = true;
const driverStatus = 'bob';

if(age >= 18) {
    console.log('Je mag naar binnen');
}
else {
    console.log('Je bent te jong');
}

if(isFemale) {
    console.log('Kom maar binnen');
}
else {
    console.log("Het is ladies night, kom maar een andere keer terug");
}

if(driverStatus === 'bob') {
    console.log('Je mag rijden.');
}
else {
    console.log('Jij bent de bob niet. Je mag niet rijden');
}