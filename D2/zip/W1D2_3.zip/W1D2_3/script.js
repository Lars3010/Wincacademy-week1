console.log('hallo winc academy studenten');

//Dit is een grote som
// let x = 1230941 * 1823794;
// console.log("1230941 x 1823794 = " + x);

// let y = 637263 / 54;
// console.log("637263 / 54 = " + y);


