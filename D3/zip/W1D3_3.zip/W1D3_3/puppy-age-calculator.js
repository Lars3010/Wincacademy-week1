let calculateDogAge = function(puppyAge, conversionRate) {
    return 'Your dog is ' + puppyAge * conversionRate + ' years old in dog years';
}

console.log(calculateDogAge(7,7));
console.log(calculateDogAge(12,7));
console.log(calculateDogAge(3,9));