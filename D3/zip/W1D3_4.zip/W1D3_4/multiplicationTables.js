for(x=0; x <= 10; x++){
    for(i=0; i <= 10; i++) {
        let sum = i * x;
        console.log(i + ' * ' + x +' = ' + sum);
    }
}